package com.example.foodtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {

    RecyclerView foodRecycler, expiringSoonRecycler;
    ArrayList<FoodItem> foodItems = new ArrayList<>();
    Button addItemBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        foodRecycler = findViewById(R.id.foodRecycler);
        expiringSoonRecycler = findViewById(R.id.expiringSoonRecycler);
        addItemBtn = findViewById(R.id.addItemBtn);

        // Dummy data
        foodItems.add(new FoodItem("Milk", "2025-04-24", 2));
        foodItems.add(new FoodItem("Bread", "2025-04-22", 0));
        foodItems.add(new FoodItem("Eggs", "2025-04-30", 8));

        foodRecycler.setAdapter(new FoodItemAdapter(foodItems, this));
        expiringSoonRecycler.setAdapter(new FoodItemAdapter(foodItems, this));

        addItemBtn.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, AddItemActivity.class));
        });

        Button settingsBtn = findViewById(R.id.settingsBtn);

        settingsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
    }



}
