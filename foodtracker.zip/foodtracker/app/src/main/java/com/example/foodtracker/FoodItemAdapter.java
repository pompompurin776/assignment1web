package com.example.foodtracker;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FoodItemAdapter extends RecyclerView.Adapter<FoodItemAdapter.ViewHolder> {

    ArrayList<FoodItem> items;
    Context context;

    public FoodItemAdapter(ArrayList<FoodItem> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public FoodItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.food_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodItemAdapter.ViewHolder holder, int position) {
        FoodItem item = items.get(position);

        holder.name.setText(item.getName());
        holder.expiry.setText("Expiry: " + item.getExpiryDate());
        holder.daysLeft.setText(item.getDaysLeft() + " day(s) left");

        if (item.getDaysLeft() <= 0) {
            holder.itemView.setBackgroundColor(Color.parseColor("#FFCDD2")); // Red
        } else if (item.getDaysLeft() <= 3) {
            holder.itemView.setBackgroundColor(Color.parseColor("#FFF9C4")); // Yellow
        } else {
            holder.itemView.setBackgroundColor(Color.parseColor("#C8E6C9")); // Green
        }

        holder.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, DetailActivity.class);
            i.putExtra("foodItem", item); // Pass the whole object
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, expiry, daysLeft;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.foodName);
            expiry = itemView.findViewById(R.id.foodExpiry);
            daysLeft = itemView.findViewById(R.id.foodDays);
        }
    }
}
