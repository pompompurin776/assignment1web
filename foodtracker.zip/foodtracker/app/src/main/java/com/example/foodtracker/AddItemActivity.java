package com.example.foodtracker;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddItemActivity extends AppCompatActivity {

    EditText foodNameEditText;
    TextView expiryDateTextView;
    Button saveButton;
    Calendar calendar = Calendar.getInstance();
    String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        foodNameEditText = findViewById(R.id.editTextFoodName);
        expiryDateTextView = findViewById(R.id.textViewExpiryDate);
        saveButton = findViewById(R.id.buttonSave);

        expiryDateTextView.setOnClickListener(view -> showDatePicker());

        saveButton.setOnClickListener(v -> {
            String foodName = foodNameEditText.getText().toString().trim();
            if (foodName.isEmpty() || selectedDate.isEmpty()) {
                Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show();
            } else {
                // Return data to DashboardActivity (you can use DB later)
                Intent intent = new Intent();
                intent.putExtra("foodName", foodName);
                intent.putExtra("expiryDate", selectedDate);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }

    private void showDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, day) -> {
            calendar.set(year, month, day);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            selectedDate = sdf.format(calendar.getTime());
            expiryDateTextView.setText(selectedDate);
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }
}
