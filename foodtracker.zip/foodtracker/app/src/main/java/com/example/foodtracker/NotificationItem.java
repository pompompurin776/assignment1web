package com.example.foodtracker;

public class NotificationItem {
    public String message;
    public String time;
    public String type;

    public NotificationItem(String message, String time, String type) {
        this.message = message;
        this.time = time;
        this.type = type;
    }
}
